//
//  Recipe.swift
//  Assignment3_Gummeson
//
//  Created by Grace Gummeson on 7/20/16.
//  Copyright © 2016 Grace Gummeson. All rights reserved.
//

import Foundation


class Recipe {
    
    let name: String
    let cookingtime: String
    let description: String
    let listofingredients: String
    let steps: String
 
    
    init(name: String, cookingtime: String, description: String, listofingredients: String, steps: String) {
        self.name = name
        self.cookingtime = cookingtime
        self.description = description
        self.listofingredients = listofingredients
        self.steps = steps
    }
    
}
