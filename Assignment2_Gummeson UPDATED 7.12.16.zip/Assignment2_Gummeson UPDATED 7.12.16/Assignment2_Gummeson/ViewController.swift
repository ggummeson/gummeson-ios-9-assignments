
//  ViewController.swift
//  Assignment2_Gummeson
//
//  Created by Grace Gummeson on 7/3/16.
//  Copyright © 2016 Grace Gummeson. All rights reserved.
//

import UIKit

class AppsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}



class AgeVerificationViewController: UIViewController {
    
    // MARK: Declaration
    
    @IBOutlet var yearofbirthTextField: UITextField!
    @IBOutlet var resultLabel: UILabel!
    
    func verifyAge (yearofbirth: Int) {
        if yearofbirth > 2000 {
            resultLabel.text = "You are a CHILD!"
        } else if yearofbirth > 1998 {
            resultLabel.text = "You can drive"
        } else if yearofbirth > 1995 {
            resultLabel.text = "You can vote and drive"
        } else {
            resultLabel.text = "You can vote, drive, and drink"
        }
    }


    // MARK: Lifecyle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Actions
    
    @IBAction func verifyButtonAction(sender: UIButton) {
//        func verifyAge (yearofbirth: Int) {
//            if yearofbirth > 2005 {
//                resultLabel.text = "You are a CHILD!"
//            } else if yearofbirth > 2002 {
//                resultLabel.text = "You can drive"
//            } else if yearofbirth > 2000 {
//                resultLabel.text = "You can vote and drive"
//            } else {
//                resultLabel.text = "You can vote, drive, and drink"
//            }
//        }
//    }
        if
            let text = yearofbirthTextField.text,
            let yearOfBirthInteger = Int(text) {
            
            verifyAge(yearOfBirthInteger)
        }
    }
}



class BillSplitterViewController: UIViewController {
    
    // MARK: Declaration

    @IBOutlet weak var billamountTextField: UITextField!
    @IBOutlet weak var tippercentageTextField: UITextField!
    @IBOutlet weak var numberofsplitsTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    func divide(leftOperand: Double, rightOperand: Double, percentage: Double) {
        if rightOperand == 0 {
            resultLabel.text = "You cannot divide by zero"
            return
        }
        if percentage == 0 {
            resultLabel.text = "No tip? Cheap-o"
            return
        }
        let result = (leftOperand / rightOperand) * percentage
        resultLabel.text = "\(result)"
        }

    
    // MARK: Lifecyle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: Action

    @IBAction func calculateButtonAction(sender: AnyObject) {
        if
            let leftOperand = billamountTextField.text,
            let leftOperandDouble = Double(leftOperand),
        
            let rightOperand = numberofsplitsTextField.text,
            let rightOperandDouble = Double(rightOperand),
        
            let percentage = tippercentageTextField.text,
            let percentageDouble = Double(percentage) {
            
            divide(leftOperandDouble, rightOperand: Double, percentageDouble: Double)
            return
            }
        
//        {func divide(leftOperand: Double, rightOperand: Double, percentage: Double) {
//                if rightOperand == 0 {
//                    resultLabel.text = "You cannot divide by zero"
//                    return
//                }
//                if percentage == 0 {
//                    resultLabel.text = "No tip? Cheap-o"
//                    return
//                }
//                let result = (leftOperand / rightOperand) * percentage
//                resultLabel.text = "\(result)"
//            }
//        }
    }
//}



class GuessTheNumberViewController: UIViewController {
    
    
    // MARK: Declaration

    @IBOutlet weak var numberTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    func guessNumber(number: Int) {
        if number == 7 {
            resultLabel.text = "You're right!"
        } else {
            resultLabel.text = "Sorry, you're wrong. Guess again!"
        }
    }


    
    // MARK: Lifecyle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: Action

    @IBAction func guessButtonAction(sender: AnyObject) {
        if
            let number = numberTextField.text,
            let numberInteger = Int(number)
        { guessNumber(numberInteger)
            return
        
//            func guessNumber(number: Int) {
//                if number == 7 {
//                    resultLabel.text = "You're right!"
//                } else {
//                    resultLabel.text = "Sorry, you're wrong. Guess again!"
//                }
//            }
        
        }
    }
}

}