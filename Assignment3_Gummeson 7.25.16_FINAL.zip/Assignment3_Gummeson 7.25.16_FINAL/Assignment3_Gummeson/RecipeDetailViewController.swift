//
//  RecipeDetailViewController.swift
//  Assignment3_Gummeson
//
//  Created by Grace Gummeson on 7/20/16.
//  Copyright © 2016 Grace Gummeson. All rights reserved.
//

import UIKit


class RecipeDetailViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var cookingtimeLabel: UILabel!
    @IBOutlet weak var listofingredientsLabel: UILabel!
    @IBOutlet weak var stepsLabel: UILabel!
    
    var particularRecipeDetail : Recipe?

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        if let particularRecipeDetail = particularRecipeDetail {
            nameLabel.text = particularRecipeDetail.name
            cookingtimeLabel.text = particularRecipeDetail.cookingtime
            listofingredientsLabel.text = particularRecipeDetail.listofingredients
            stepsLabel.text = particularRecipeDetail.steps
        }
    }

}