//
//  ViewController.swift
//  Assignment3_Gummeson
//
//  Created by Grace Gummeson on 7/20/16.
//  Copyright © 2016 Grace Gummeson. All rights reserved.
//

import UIKit

class MainListTableViewController: UITableViewController {

  
    // MARK: Declaration
    
    var myRecipes = [Recipe]()
    
    
    // MARK: Segue
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "detailsegueidentifier" {
            if let particularRecipeDetailViewController = segue.destinationViewController as? RecipeDetailViewController {
                if let indexPath = tableView.indexPathForSelectedRow {
                    let particularRecipeDetail = myRecipes[indexPath.row]
                    particularRecipeDetailViewController.particularRecipeDetail = particularRecipeDetail
                }
            }
        }
    }
    
    
    
    // MARK: UITableViewDataSource
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let recipedetails = [
            
            Recipe(name: "Peanut Butter and Jelly", cookingtime: "5 minute cooktime", description: "Perfect combination of sweet and salty!", listofingredients: "Peanut Butter, Jelly, Bread", steps: "As simple as spreading your peanut butter and jelly on either side of two peices of bread"),
            Recipe(name: "Peanut Butter and Fluff", cookingtime: "5 minute cooktime", description: "If you have a sweet tooth, this sandwich is for you!", listofingredients: "Peanut Butter, Marshmellow Fluff, Bread", steps: "As simple as spreading your peanut butter and marshmellow fluff on either side of two peices of bread"),
            Recipe(name: "PeanutButter and Banana", cookingtime: "5 minute cooktime", description: "A favorit of Elvis, simple to make, and tasty to eat!", listofingredients: "Peanut Butter, Banana, Bread", steps: "As simple as spreading your peanut butter and placing your cut up banana on either side of two peices of bread")
        ]
        
        myRecipes.appendContentsOf(recipedetails)
    }
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myRecipes.count }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell =
            tableView.dequeueReusableCellWithIdentifier("maincellidentifier", forIndexPath: indexPath)
        
        let Recipe = myRecipes[indexPath.row]
        cell.textLabel?.text = Recipe.name
        cell.detailTextLabel?.text = Recipe.cookingtime
        
        
        return cell
    }


}


