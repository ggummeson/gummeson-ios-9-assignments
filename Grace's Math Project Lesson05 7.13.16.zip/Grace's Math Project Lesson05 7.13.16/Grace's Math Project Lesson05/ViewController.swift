//
//  ViewController.swift
//  Grace's Math Project Lesson05
//
//  Created by Grace Gummeson on 7/13/16.
//  Copyright © 2016 Grace Gummeson. All rights reserved.
//

import UIKit

class MathViewController: UIViewController {
    
    // MARK: Declaration

    @IBOutlet weak var leftoperandTextField: UITextField!
    @IBOutlet weak var rightoperandTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    
    
    func addition (leftOperand: Int, rightOperand: Int) {
        let result = leftOperand + rightOperand
        resultLabel.text = "\(result)"
    }
    
    
    func subtract (leftOperand: Int, rightOperand: Int) {
        let result = leftOperand - rightOperand
        resultLabel.text = "\(result)"
    }
    
    
    func multiply (leftOperand: Int, rightOperand: Int) {
        let result = leftOperand * rightOperand
        resultLabel.text = "\(result)"
    }
    
    
    func divide (leftOperand: Int, rightOperand: Int) {
        if rightOperand == 0 {
            resultLabel.text = "You cannot divide by zero"
            return
        }
        let result = leftOperand / rightOperand
        resultLabel.text = "\(result)"
    }
    
    
    
    // MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    // MARK: Action
    
    

    @IBAction func addButtonAction(sender: AnyObject) {
        if
            let leftOperand = leftoperandTextField.text,
            let rightOperand = rightoperandTextField.text,
        
            let leftOperandInteger = Int(leftOperand),
            let rightOperandInteger = Int(rightOperand) {
        
//            addition(leftOperandInteger, rightOperandInteger: Int)
        
        }
    }



    
    @IBAction func subtractButtonAction(sender: AnyObject) {
        if
            let leftOperand = leftoperandTextField.text,
            let rightOperand = rightoperandTextField.text,
            
            let leftOperandInteger = Int(leftOperand),
            let rightOperandInteger = Int(rightOperand) {
            
//            subtract(leftOperandInteger, rightOperandInteger: Int)
            
        }
    }


    
    @IBAction func multiplyButtonAction(sender: AnyObject) {
        if
            let leftOperand = leftoperandTextField.text,
            let rightOperand = rightoperandTextField.text,
            
            let leftOperandInteger = Int(leftOperand),
            let rightOperandInteger = Int(rightOperand) {
            
//            multiply (leftOperandInteger, rightOperandInteger: Int)
            
        }
    
    
    }

    
    

    @IBAction func divideButtonAction(sender: AnyObject) {
        if
            let leftOperand = leftoperandTextField.text,
            let rightOperand = rightoperandTextField.text,
            
            let leftOperandInteger = Int(leftOperand),
            let rightOperandInteger = Int(rightOperand) {
            
//            multiply (leftOperandInteger, rightOperandInteger: Int)
            
        }
    }
    
    
}

