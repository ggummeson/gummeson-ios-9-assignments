//
//  RecipeDetailViewController.swift
//  Assignment3_Gummeson
//
//  Created by Grace Gummeson on 7/20/16.
//  Copyright © 2016 Grace Gummeson. All rights reserved.
//

import UIKit


class RecipeDetailViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var cookingtimeLabel: UILabel!
    @IBOutlet weak var listofingredientsLabel: UILabel!
    @IBOutlet weak var stepsLabel: UILabel!
    
    var recipedetail : Recipe?

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        if let Recipe = Recipe {
            nameLabel.text = Recipe.name
            cookingtimeLabel.text = Recipe.cookingtime
            listofingredientsLabel.text = Recipe.listofingredients
            stepsLabel.text = Recipe.text
        }
    }
}
