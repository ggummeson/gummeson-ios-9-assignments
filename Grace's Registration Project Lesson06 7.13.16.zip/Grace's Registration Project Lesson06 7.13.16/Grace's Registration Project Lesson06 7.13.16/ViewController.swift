//
//  ViewController.swift
//  Grace's Registration Project Lesson06 7.13.16
//
//  Created by Grace Gummeson on 7/13/16.
//  Copyright © 2016 Grace Gummeson. All rights reserved.
//

import UIKit

class RegistrationViewController: UIViewController {
    
    
    // MARK: Declartaion
    
    
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var usernameverificationTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var passwordverificationTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!

    
    // MARK: Lifecyle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
    // MARK: Action
    
    @IBAction func registerButtonAction(sender: AnyObject) {
        if usernameTextField.text == usernameverificationTextField.text && passwordTextField.text == passwordverificationTextField.text {
            if
                let username = usernameTextField.text,
                let password = passwordTextField.text {
                if username.characters.count > 5 && password.characters.count > 5 {
                    resultLabel.text = "Successful Registration"
                } else {
                    resultLabel.text = "Failed Registration"
                }
            } else {
                resultLabel.text = "Failed Registration"
            }
        }
    }



}

